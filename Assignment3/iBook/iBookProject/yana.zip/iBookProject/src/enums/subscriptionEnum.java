package enums;

public class subscriptionEnum {

	public enum subscription {none,monthly,yearly}
}
