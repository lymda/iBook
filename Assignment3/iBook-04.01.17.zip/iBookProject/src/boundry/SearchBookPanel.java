package boundry;
 
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import controller.*;
import java.util.*;


public class SearchBookPanel extends JPanel
	                     implements ActionListener {
    static JFrame frame;
    SearchBookController srchBookCtrl;
    String[] categoriesName;
    String[] authorsName;
    String[] langsName;
    private int chosenCatID;
    
	private JTextField tfTitle;
	private JComboBox cbLanguage;
	private JComboBox cbSubject;
	private JComboBox cbCategory;
	private JComboBox cbAuthor;
	private JRadioButton rdbtnOr;
	private JRadioButton rdbtnAnd;
 
    public SearchBookPanel() {
    	srchBookCtrl = new SearchBookController();
		srchBookCtrl.GetAllCatsAndSubs();
		categoriesName = srchBookCtrl.GetCategoriesName();
		srchBookCtrl.GetAllAuthors();
		authorsName = srchBookCtrl.GetAuthorsName();
		srchBookCtrl.GetAllLanguages();
		langsName = srchBookCtrl.GetLanguagesName();
		
    	initialize();
    }
    
    
	private void initialize() {
		setLayout(null);
		
		JLabel lblSearchTitle = new JLabel("Search for book");
		lblSearchTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblSearchTitle.setFont(new Font("Goudy Stout", Font.PLAIN, 15));
		lblSearchTitle.setBounds(0, 21, 336, 20);
		add(lblSearchTitle);
		
		JLabel lblInst = new JLabel("Please insert book details to search:");
		lblInst.setFont(new Font("Berlin Sans FB Demi", Font.PLAIN, 14));
		lblInst.setBounds(20, 67, 233, 20);
		add(lblInst);
		
		JLabel lblTitle = new JLabel("Title:");
		lblTitle.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblTitle.setBounds(20, 126, 68, 14);
		add(lblTitle);
		
		tfTitle = new JTextField();
		tfTitle.setColumns(10);
		tfTitle.setBounds(98, 123, 155, 20);
		add(tfTitle);
		
		JLabel lblAuthor = new JLabel("Author:");
		lblAuthor.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblAuthor.setBounds(20, 151, 68, 14);
		add(lblAuthor);
		
        cbAuthor = new JComboBox(authorsName);
        cbAuthor.setEditable(true);
        cbAuthor.setBounds(98, 148, 155, 20);
        add(cbAuthor);
		
        JLabel lblLanguage = new JLabel("Language:");
		lblLanguage.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblLanguage.setBounds(20, 176, 68, 14);
		add(lblLanguage);
		
		cbLanguage = new JComboBox(langsName);
		cbLanguage.setEditable(true);
		cbLanguage.setBounds(98, 173, 155, 20);
		add(cbLanguage);
		
		JLabel lblCategory = new JLabel("Category:");
		lblCategory.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblCategory.setBounds(20, 201, 68, 14);
		add(lblCategory);
		
		JLabel lblSubject = new JLabel("Subject:");
		lblSubject.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblSubject.setEnabled(false);
		lblSubject.setBounds(20, 226, 68, 14);
		add(lblSubject);
		
		cbSubject = new JComboBox();
		cbSubject.setEnabled(false);
		cbSubject.setBounds(98, 223, 155, 20);
		add(cbSubject);
		
		JLabel lblSearchBy = new JLabel("Search by:");
		lblSearchBy.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		lblSearchBy.setEnabled(false);
		lblSearchBy.setBounds(20, 252, 72, 20);
		add(lblSearchBy);
		
		rdbtnOr = new JRadioButton("OR");
		rdbtnOr.setEnabled(false);
		rdbtnOr.setBounds(176, 248, 58, 23);
		add(rdbtnOr);
		
		rdbtnAnd = new JRadioButton("AND");
		rdbtnAnd.setSelected(true);
		rdbtnAnd.setEnabled(false);
		rdbtnAnd.setBounds(98, 250, 58, 23);
		add(rdbtnAnd);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SearchBook();
			}
		});
		btnSearch.setFont(new Font("Sitka Text", Font.PLAIN, 14));
		btnSearch.setBounds(108, 278, 89, 23);
		add(btnSearch);
               
        cbCategory = new JComboBox(categoriesName);
        cbCategory.setBounds(98, 198, 155, 20);
        add(cbCategory);
        cbCategory.setEditable(true);
        cbCategory.addActionListener(this);
        cbCategory.setAlignmentX(Component.LEFT_ALIGNMENT);
        
    } //constructor
 
    public void actionPerformed(ActionEvent e) {
        JComboBox cb = (JComboBox)e.getSource();
        String selection = (String)cb.getSelectedItem();
        if(!selection.equals(""))
        {
	        chosenCatID = srchBookCtrl.GetCategoryIDByName(selection);
	        if(chosenCatID == -1) return;
	        
	        System.out.println("chosenCatID= "+chosenCatID);
	        cbSubject.removeAllItems();
	        ArrayList<String> subName = srchBookCtrl.GetSubjectsByCategory(chosenCatID);
	        for(String val: subName)
	        	cbSubject.addItem(val);
			cbSubject.setEnabled(true);
        }
        else
        {
        	cbSubject.removeAllItems();
        	cbSubject.setEnabled(false);
        }
        
    }

    
	private void SearchBook(){
		int fieldsCount = 0;
		// Check if all fields are empty - a search not performed.
		if(tfTitle.getText().equals("") &&
				cbAuthor.getSelectedItem().equals("") &&
				cbLanguage.getSelectedItem().equals("") &&
				cbCategory.getSelectedItem().equals("") &&
				cbSubject.getItemCount() == 0)
		{
			JOptionPane.showMessageDialog(null,"Please insert any value for search.", "Search Error",JOptionPane.ERROR_MESSAGE);

			rdbtnOr.setEnabled(false);
			rdbtnAnd.setEnabled(false);
		}
		else
		{
			fieldsCount = 0;
			if(!tfTitle.getText().equals("")) fieldsCount++;
			if(!cbAuthor.getSelectedItem().equals("")) fieldsCount++;
			if(!cbLanguage.getSelectedItem().equals("")) fieldsCount++;
			if(!cbCategory.getSelectedItem().equals("")) fieldsCount++;
			
			if(fieldsCount > 1)
			{
				JOptionPane.showMessageDialog(null,"You selected more then 1 field to search.\n"
						+ "please choose search option(OR / AND).", "Search Info",JOptionPane.INFORMATION_MESSAGE);

				rdbtnOr.setEnabled(true);
				rdbtnAnd.setEnabled(true);
			}
			else
			{
				rdbtnOr.setEnabled(false);
				rdbtnAnd.setEnabled(false);
			}
		}
	}
}
